package com.osmanavsar.mycalculator

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    fun mySum(view : View){
        val editText = findViewById<EditText>(R.id.editText)
        val editText2 = findViewById<EditText>(R.id.editText2)
        val textView = findViewById<TextView>(R.id.textView)

        val num1 = editText.text.toString().toIntOrNull()
        val num2 = editText2.text.toString().toIntOrNull()

        if(num1 != null && num2 != null){
            val res = num1!! + num2!!
            textView.text = "Result: ${res}"
        } else {
            val res = "Give me a good input."
            textView.text = "Result: ${res}"
        }
    }

    fun mySub(view : View){
        val editText = findViewById<EditText>(R.id.editText)
        val editText2 = findViewById<EditText>(R.id.editText2)
        val textView = findViewById<TextView>(R.id.textView)

        val num1 = editText.text.toString().toIntOrNull()
        val num2 = editText2.text.toString().toIntOrNull()

        if(num1 != null && num2 != null){
            val res = num1!! - num2!!
            textView.text = "Result: ${res}"
        } else {
            val res = "Give me a good input."
            textView.text = "Result: ${res}"
        }
    }

    fun myMulti(view : View){
        val editText = findViewById<EditText>(R.id.editText)
        val editText2 = findViewById<EditText>(R.id.editText2)
        val textView = findViewById<TextView>(R.id.textView)

        val num1 = editText.text.toString().toIntOrNull()
        val num2 = editText2.text.toString().toIntOrNull()

        if(num1 != null && num2 != null){
            val res = num1!! * num2!!
            textView.text = "Result: ${res}"
        } else {
            val res = "Give me a good input."
            textView.text = "Result: ${res}"
        }
    }

    fun myDiv(view : View){
        val editText = findViewById<EditText>(R.id.editText)
        val editText2 = findViewById<EditText>(R.id.editText2)
        val textView = findViewById<TextView>(R.id.textView)

        val num1 = editText.text.toString().toIntOrNull()
        val num2 = editText2.text.toString().toIntOrNull()

        if(num1 != null && num2 != null){
            val res = num1!! / num2!!
            textView.text = "Result: ${res}"
        } else {
            val res = "Give me a good input."
            textView.text = "Result: ${res}"
        }
    }
}